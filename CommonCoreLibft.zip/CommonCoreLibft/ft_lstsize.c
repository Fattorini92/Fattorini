/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstsize.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gfattori <gfattori@learner.42.tech>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/11/11 14:31:12 by gfattori          #+#    #+#             */
/*   Updated: 2026/11/11 14:31:22 by gfattori         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

Prototype unsigned int ft_lstsize(t_list *lst);
Files to Submit -
Parameters lst: The beginning of the list.
Return Value The length of the list
External Functions None
Description Counts the number of nodes in the list.
