/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putstr_fd.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gfattori <gfattori@learner.42.tech>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/11/11 14:27:48 by gfattori          #+#    #+#             */
/*   Updated: 2026/11/11 14:28:09 by gfattori         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

Prototype void ft_putstr_fd(char *s, int fd);
Files to Submit -
Parameters s: The string to output.
fd: The file descriptor on which to write.
Return Value None
External Functions write
Description Outputs the string ’s’ to the given file descriptor.
