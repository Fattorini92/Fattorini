/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr_fd.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gfattori <gfattori@learner.42.tech>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/11/11 14:28:59 by gfattori          #+#    #+#             */
/*   Updated: 2026/11/11 14:29:08 by gfattori         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

Prototype void ft_putnbr_fd(int n, int fd);
Files to Submit -
Parameters n: The integer to output.
fd: The file descriptor on which to write.
Return Value None
External Functions write
Description Outputs the integer ’n’ to the given file descriptor.
